import {
  BookOpen,
  ChevronLeft,
  ChevronRight,
  Clock3,
  Search,
  UserRound,
} from "lucide-react";
import { useCallback, useEffect, useState } from "react";

import {
  getAdminRecipeFilters,
  getAdminRecipes,
  type AdminRecipe,
  type AdminRecipeFilter,
} from "../../api/admin.api";

const PAGE_SIZE = 12;

const statusOptions = [
  { value: "", label: "All statuses" },
  { value: "published", label: "Published" },
  { value: "pending", label: "Pending" },
  { value: "rejected", label: "Rejected" },
];

const statusClasses: Record<string, string> = {
  published:
    "bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400",
  pending:
    "bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-400",
  rejected: "bg-red-50 text-red-700 dark:bg-red-500/10 dark:text-red-400",
};

const formatDate = (value: string) =>
  new Intl.DateTimeFormat("en", {
    month: "short",
    day: "numeric",
    year: "numeric",
  }).format(new Date(value));

const formatCookingTime = (minutes: number | null) => {
  if (!minutes) return "—";

  if (minutes < 60) {
    return `${minutes} min`;
  }

  const hours = Math.floor(minutes / 60);
  const remaining = minutes % 60;

  return remaining ? `${hours}h ${remaining}m` : `${hours}h`;
};

const getInitials = (name: string) =>
  name
    .split(" ")
    .map((part) => part[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

const getStatusLabel = (status: string) =>
  status.charAt(0).toUpperCase() + status.slice(1);

export default function AdminRecipesPage() {
  const [recipes, setRecipes] = useState<AdminRecipe[]>([]);
  const [categories, setCategories] = useState<AdminRecipeFilter[]>([]);
  const [cuisines, setCuisines] = useState<AdminRecipeFilter[]>([]);

  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");

  const [status, setStatus] = useState("");
  const [category, setCategory] = useState("");
  const [cuisine, setCuisine] = useState("");

  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);

  const [loading, setLoading] = useState(true);
  const [filtersLoading, setFiltersLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const timeout = window.setTimeout(() => {
      setDebouncedSearch(search);
      setPage(1);
    }, 300);

    return () => window.clearTimeout(timeout);
  }, [search]);

  useEffect(() => {
    const loadFilters = async () => {
      try {
        setFiltersLoading(true);

        const result = await getAdminRecipeFilters();

        setCategories(result.categories);
        setCuisines(result.cuisines);
      } catch (err) {
        console.error(err);
      } finally {
        setFiltersLoading(false);
      }
    };

    void loadFilters();
  }, []);

  const loadRecipes = useCallback(async () => {
    try {
      setLoading(true);
      setError("");

      const result = await getAdminRecipes({
        search: debouncedSearch,
        status,
        category,
        cuisine,
        page,
        limit: PAGE_SIZE,
      });

      setRecipes(result.recipes);
      setTotal(result.pagination.total);
      setTotalPages(Math.max(1, result.pagination.totalPages));
    } catch (err) {
      console.error(err);

      setError(err instanceof Error ? err.message : "Unable to load recipes.");
    } finally {
      setLoading(false);
    }
  }, [debouncedSearch, status, category, cuisine, page]);

  useEffect(() => {
    const loadRecipesTimeout = window.setTimeout(() => {
      void loadRecipes();
    }, 0);

    return () => window.clearTimeout(loadRecipesTimeout);
  }, [loadRecipes]);

  const handleStatusChange = (value: string) => {
    setStatus(value);
    setPage(1);
  };

  const handleCategoryChange = (value: string) => {
    setCategory(value);
    setPage(1);
  };

  const handleCuisineChange = (value: string) => {
    setCuisine(value);
    setPage(1);
  };

  const hasFilters =
    Boolean(search) || Boolean(status) || Boolean(category) || Boolean(cuisine);

  const clearFilters = () => {
    setSearch("");
    setDebouncedSearch("");
    setStatus("");
    setCategory("");
    setCuisine("");
    setPage(1);
  };

  return (
    <div className="space-y-6">
      <div>
        <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
              Recipes
            </h1>

            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              Manage recipes across the KinFeast platform.
            </p>
          </div>

          <div className="text-sm text-slate-500 dark:text-slate-400">
            {total} {total === 1 ? "recipe" : "recipes"}
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_180px_180px_180px_auto]">
          <div className="relative">
            <Search
              size={18}
              className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
            />

            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search recipes or chefs..."
              className="h-11 w-full rounded-xl border border-slate-200 bg-slate-50 pl-10 pr-4 text-sm text-slate-900 outline-none transition focus:border-slate-400 focus:bg-white dark:border-slate-700 dark:bg-slate-950 dark:text-white dark:focus:border-slate-500 dark:focus:bg-slate-950"
            />
          </div>

          <select
            value={status}
            onChange={(event) => handleStatusChange(event.target.value)}
            className="h-11 rounded-xl border border-slate-200 bg-slate-50 px-3 text-sm text-slate-700 outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
          >
            {statusOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>

          <select
            value={category}
            onChange={(event) => handleCategoryChange(event.target.value)}
            disabled={filtersLoading}
            className="h-11 rounded-xl border border-slate-200 bg-slate-50 px-3 text-sm text-slate-700 outline-none disabled:opacity-60 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
          >
            <option value="">All categories</option>

            {categories.map((item) => (
              <option key={item.id} value={item.slug}>
                {item.name}
              </option>
            ))}
          </select>

          <select
            value={cuisine}
            onChange={(event) => handleCuisineChange(event.target.value)}
            disabled={filtersLoading}
            className="h-11 rounded-xl border border-slate-200 bg-slate-50 px-3 text-sm text-slate-700 outline-none disabled:opacity-60 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
          >
            <option value="">All cuisines</option>

            {cuisines.map((item) => (
              <option key={item.id} value={item.slug}>
                {item.name}
              </option>
            ))}
          </select>

          {hasFilters && (
            <button
              type="button"
              onClick={clearFilters}
              className="h-11 rounded-xl px-4 text-sm font-medium text-slate-600 transition hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {error && (
        <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900/50 dark:bg-red-500/10 dark:text-red-300">
          {error}
        </div>
      )}

      <div className="hidden overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900 md:block">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px]">
            <thead>
              <tr className="border-b border-slate-200 text-left dark:border-slate-800">
                <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Recipe
                </th>

                <th className="px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Chef
                </th>

                <th className="px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Category
                </th>

                <th className="px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Cuisine
                </th>

                <th className="px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Status
                </th>

                <th className="px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Created
                </th>
              </tr>
            </thead>

            <tbody>
              {loading ? (
                Array.from({ length: 6 }).map((_, index) => (
                  <tr
                    key={index}
                    className="border-b border-slate-100 last:border-0 dark:border-slate-800"
                  >
                    {Array.from({ length: 6 }).map((_, cellIndex) => (
                      <td key={cellIndex} className="px-4 py-5">
                        <div className="h-4 animate-pulse rounded bg-slate-100 dark:bg-slate-800" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : recipes.length > 0 ? (
                recipes.map((recipe) => (
                  <tr
                    key={recipe.id}
                    className="border-b border-slate-100 transition last:border-0 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800/40"
                  >
                    <td className="px-6 py-5">
                      <div className="max-w-[280px]">
                        <p className="truncate font-semibold text-slate-900 dark:text-white">
                          {recipe.title}
                        </p>

                        <div className="mt-1 flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
                          <span className="flex items-center gap-1">
                            <Clock3 size={13} />
                            {formatCookingTime(recipe.cooking_time)}
                          </span>

                          {recipe.difficulty && (
                            <span>{recipe.difficulty}</span>
                          )}
                        </div>
                      </div>
                    </td>

                    <td className="px-4 py-5">
                      <div className="flex items-center gap-3">
                        {recipe.author_profile_image ? (
                          <img
                            src={recipe.author_profile_image}
                            alt=""
                            className="h-9 w-9 rounded-full object-cover"
                          />
                        ) : (
                          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-100 text-xs font-semibold text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                            {getInitials(recipe.author_name)}
                          </div>
                        )}

                        <div>
                          <p className="text-sm font-medium text-slate-900 dark:text-white">
                            {recipe.author_name}
                          </p>

                          <p className="text-xs text-slate-500 dark:text-slate-400">
                            {recipe.author_email}
                          </p>
                        </div>
                      </div>
                    </td>

                    <td className="px-4 py-5 text-sm text-slate-600 dark:text-slate-300">
                      {recipe.category_name}
                    </td>

                    <td className="px-4 py-5 text-sm text-slate-600 dark:text-slate-300">
                      {recipe.cuisine_name}
                    </td>

                    <td className="px-4 py-5">
                      <span
                        className={`inline-flex rounded-full px-2.5 py-1 text-xs font-semibold ${
                          statusClasses[recipe.status]
                        }`}
                      >
                        {getStatusLabel(recipe.status)}
                      </span>
                    </td>

                    <td className="px-4 py-5 text-sm text-slate-500 dark:text-slate-400">
                      {formatDate(recipe.created_at)}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="px-6 py-16 text-center">
                    <BookOpen
                      size={36}
                      className="mx-auto text-slate-300 dark:text-slate-700"
                    />

                    <p className="mt-4 font-semibold text-slate-900 dark:text-white">
                      No recipes found
                    </p>

                    <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
                      Try changing your search or filters.
                    </p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="space-y-3 md:hidden">
        {loading ? (
          Array.from({ length: 5 }).map((_, index) => (
            <div
              key={index}
              className="h-40 animate-pulse rounded-2xl bg-slate-100 dark:bg-slate-900"
            />
          ))
        ) : recipes.length > 0 ? (
          recipes.map((recipe) => (
            <div
              key={recipe.id}
              className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <h3 className="truncate font-semibold text-slate-900 dark:text-white">
                    {recipe.title}
                  </h3>

                  <div className="mt-2 flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                    <Clock3 size={13} />

                    {formatCookingTime(recipe.cooking_time)}

                    {recipe.difficulty && (
                      <>
                        <span>•</span>
                        <span>{recipe.difficulty}</span>
                      </>
                    )}
                  </div>
                </div>

                <span
                  className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-semibold ${
                    statusClasses[recipe.status]
                  }`}
                >
                  {getStatusLabel(recipe.status)}
                </span>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-xs text-slate-400">Chef</p>

                  <div className="mt-1 flex items-center gap-2">
                    <UserRound size={14} className="text-slate-400" />

                    <span className="truncate text-slate-700 dark:text-slate-300">
                      {recipe.author_name}
                    </span>
                  </div>
                </div>

                <div>
                  <p className="text-xs text-slate-400">Category</p>

                  <p className="mt-1 truncate text-slate-700 dark:text-slate-300">
                    {recipe.category_name}
                  </p>
                </div>

                <div>
                  <p className="text-xs text-slate-400">Cuisine</p>

                  <p className="mt-1 truncate text-slate-700 dark:text-slate-300">
                    {recipe.cuisine_name}
                  </p>
                </div>

                <div>
                  <p className="text-xs text-slate-400">Created</p>

                  <p className="mt-1 text-slate-700 dark:text-slate-300">
                    {formatDate(recipe.created_at)}
                  </p>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="rounded-2xl border border-slate-200 bg-white px-6 py-14 text-center dark:border-slate-800 dark:bg-slate-900">
            <BookOpen
              size={36}
              className="mx-auto text-slate-300 dark:text-slate-700"
            />

            <p className="mt-4 font-semibold text-slate-900 dark:text-white">
              No recipes found
            </p>

            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              Try changing your search or filters.
            </p>
          </div>
        )}
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white px-4 py-3 dark:border-slate-800 dark:bg-slate-900">
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Page {page} of {totalPages}
          </p>

          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={page <= 1}
              onClick={() => setPage((current) => Math.max(1, current - 1))}
              className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 text-slate-600 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
              aria-label="Previous page"
            >
              <ChevronLeft size={18} />
            </button>

            <button
              type="button"
              disabled={page >= totalPages}
              onClick={() =>
                setPage((current) => Math.min(totalPages, current + 1))
              }
              className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 text-slate-600 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
              aria-label="Next page"
            >
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
